/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package academy.model;

import com.sun.jdi.connect.spi.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;

/**
 *
 * @author AlumnadoTarde
 */
public class academyModel {
    private Connection conexion;
    private String servidor;
    private String usuario;
    private String password;
    public Connection getConexion(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/" + servidor, usuario, password);
        } catch (ClassNotFoundException cnfe) {
            System.out.println(cnfe);
        } catch (SQLException sqle) {
            System.out.println(sqle);
        }
        return conexion;
    }
    public boolean registrarCurso(Curso curs) {
        String sentenciaSql = "INSERT INTO cursos (cod_curso, nombre, duracion, titutlo, Maestro) VALUES (?,?,?,?,?)";
        PreparedStatement sentencia = null;
        conexion = getConexion();
        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setInt(1, curs.getCode());
            sentencia.setString(2, curs.getName());
            sentencia.setInt(3, curs.getDuration());
            sentencia.setString(4, curs.getTitle());
            sentencia.setString(5, curs.getTeacher().getDni());
            sentencia.executeUpdate();
            return true;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return false;
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }
        }
    }
    public boolean modificarCurso(Curso curs) {
        String sentenciaSql = "UPDATE cursos SET cod_curso = ?, nombre = ?, duracion = ?, titutlo = ?, Maestro = ? " + "WHERE cod_curso = ?";
        PreparedStatement sentencia = null;
        conexion = getConexion();
        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setInt(1, curs.getCode());
            sentencia.setString(2, curs.getName());
            sentencia.setInt(3, curs.getDuration());
            sentencia.setString(4, curs.getTitle());
            sentencia.setString(5, curs.getTeacher().getDni());
            sentencia.executeUpdate();
            return true;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return false;
        } finally {
            if (sentencia != null)
            try {
                sentencia.close();
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }
    }
    public boolean eliminarCurso(Curso curs) {
        String sentenciaSql = "DELETE FROM cursos WHERE cod_curso = ?";
        PreparedStatement sentencia = null;
        conexion = getConexion();
        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setInt(1, curs.getCode());
            sentencia.executeUpdate();
            return true;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return false;
        } finally {
            if (sentencia != null)
            try {
                sentencia.close();
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }
    }
    public boolean registrarMaestro(Maestro maest) {
        String sentenciaSql = "INSERT INTO profesores (dni_pof, nombre, apellidos, direccion, Telefono) VALUES (?,?,?,?,?)";
        PreparedStatement sentencia = null;
        conexion = getConexion();
        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setString(1, maest.getDni());
            sentencia.setString(2, maest.getName());
            sentencia.setString(3, maest.getSurname());
            sentencia.setString(4, maest.getDirection());
            sentencia.setInt(5, maest.getPhoneNumber());
            sentencia.executeUpdate();
            return true;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return false;
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }
        }
    }
    public boolean modificarMaestro(Maestro maest) {
        String sentenciaSql = "UPDATE profesores SET dni_pof = ?, nombre = ?, apellidos = ?, direccion = ?, Telefono = ? " + "WHERE dni_pof = ?";
        PreparedStatement sentencia = null;
        conexion = getConexion();
        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setString(1, maest.getDni());
            sentencia.setString(2, maest.getName());
            sentencia.setString(3, maest.getSurname());
            sentencia.setString(4, maest.getDirection());
            sentencia.setInt(5, maest.getPhoneNumber());
            sentencia.executeUpdate();
            return true;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return false;
        } finally {
            if (sentencia != null)
            try {
                sentencia.close();
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }
    }
    public boolean eliminarMaestro(Maestro maest) {
        String sentenciaSql = "DELETE FROM profesores WHERE dni_pof = ?";
        PreparedStatement sentencia = null;
        conexion = getConexion();
        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setString(1, maest.getDni());
            sentencia.executeUpdate();
            return true;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return false;
        } finally {
            if (sentencia != null)
            try {
                sentencia.close();
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }
    }
    public boolean registrarAlumno(Alumno alum) {
        String sentenciaSql = "INSERT INTO alumno (DNI, Nombre, Edad, Direccion, Telefono, Empleo) VALUES (?,?,?,?,?,?)";
        PreparedStatement sentencia = null;
        conexion = getConexion();
        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setString(1, alum.getDni());
            sentencia.setString(2, alum.getName());
            sentencia.setInt(3, alum.getAge());
            sentencia.setString(4, alum.getDirection());
            sentencia.setInt(5, alum.getPhoneNumber());
            sentencia.setString(6, alum.getEmployed());
            sentencia.executeUpdate();
            return true;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return false;
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }
        }
    }
    public boolean modificarAlumno(Alumno alum) {
        String sentenciaSql = "UPDATE alumno SET DNI = ?, Nombre = ?, Edad = ?, Direccion = ?, Telefono = ?, Empleo = ? " + "WHERE DNI = ?";
        PreparedStatement sentencia = null;
        conexion = getConexion();
        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setString(1, alum.getDni());
            sentencia.setString(2, alum.getName());
            sentencia.setInt(3, alum.getAge());
            sentencia.setString(4, alum.getDirection());
            sentencia.setInt(5, alum.getPhoneNumber());
            sentencia.setString(6, alum.getEmployed());
            sentencia.executeUpdate();
            return true;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return false;
        } finally {
            if (sentencia != null)
            try {
                sentencia.close();
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }
    }
    public boolean eliminarAlumno(Alumno alum) {
        String sentenciaSql = "DELETE FROM alumno WHERE DNI = ?";
        PreparedStatement sentencia = null;
        conexion = getConexion();
        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setString(1, alum.getDni());
            sentencia.executeUpdate();
            return true;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return false;
        } finally {
            if (sentencia != null)
            try {
                sentencia.close();
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }
    }
}
