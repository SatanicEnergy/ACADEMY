/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package academy.model;

import com.sun.jdi.connect.spi.Connection;
import java.sql.SQLException;

/**
 *
 * @author AlumnadoTarde
 */
public class academyModel {
    public boolean registrarCurso(Curso curs) {
        String sentenciaSql = "INSERT INTO cursos VALUES (?,?,?,?,?)";
        PreparedStatement sentencia = null;
        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setInt(1, curs.getCode());
            sentencia.setString(2, curs.getName());
            sentencia.setInt(3, curs.getDuration());
            sentencia.setString(4, curs.getTitle());
            sentencia.setString(5, curs.getTeacher().getDni());
            sentencia.executeUpdate();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }
        }
    }
}
