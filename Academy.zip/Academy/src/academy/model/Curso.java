/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package academy.model;

/**
 *
 * @author EL_GR
 */
public class Curso {
    private int code;
    private String name;
    private String title;
    private int duration;
    private Maestro teacher;
    
    public Curso(int code, String name, String title, int duration, Maestro teacher) {
        this.code = code;
        this.title = title;
        this.duration = duration;
        this.teacher = teacher;
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public Maestro getTeacher() {
        return teacher;
    }

    public void setTeacher(Maestro teacher) {
        this.teacher = teacher;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
